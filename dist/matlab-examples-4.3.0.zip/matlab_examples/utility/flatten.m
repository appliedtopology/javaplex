function index = flatten(i, j, I, J)
    index = J * (i - 1) + j;
end