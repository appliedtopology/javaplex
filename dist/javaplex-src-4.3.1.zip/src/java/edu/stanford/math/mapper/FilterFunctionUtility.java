package edu.stanford.math.mapper;


public class FilterFunctionUtility {
	
}
