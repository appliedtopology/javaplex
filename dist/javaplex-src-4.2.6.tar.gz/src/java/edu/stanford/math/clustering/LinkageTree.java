package edu.stanford.math.clustering;

public class LinkageTree {
	protected double[] mergeDistances;
	protected int[][] mergePairs;
}
